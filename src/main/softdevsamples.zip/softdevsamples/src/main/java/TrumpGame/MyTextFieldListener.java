package TrumpGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyTextFieldListener implements ActionListener {
    private final DaifugoApplication simple1;

    public MyTextFieldListener(DaifugoApplication simple1) {
        this.simple1 = simple1;
    }

    public void actionPerformed(ActionEvent arg0) {
        //simple1.echoText();
    }

}
