package TrumpGame;

import java.util.ArrayList;
import java.util.Random;

import TrumpGame.Card;
import TrumpGame.CardDeck;
import TrumpGame.Player;

/**
 * 大富豪ゲームを表すクラス
 *
 * @author 浅野卓磨
 *
 */
public class DaifugoGame {
    /** プレイヤリスト */
    private ArrayList<Player> players = new ArrayList<Player>();
    /** 場札 */
    private ArrayList<ArrayList<Card>> ba = new ArrayList<ArrayList<Card>>();
    /** 山札 */
    private CardDeck yamafuda = new CardDeck();

    Random rand = new Random();

    /**
     * 空の大富豪ゲームインスタンスを作る
     */
    public DaifugoGame() {
        super();
    }

    /**
     * プレイヤリストを取得する
     * @return プレイヤリスト
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * プレイヤリストをセットする
     * @param players
     */
    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    /**
     * 場札を取得する
     * @return 場札
     */
    public ArrayList<ArrayList<Card>> getBa() {
        return ba;
    }

    /**
     * 場札をセットする
     * @param ba
     */
    public void setBa(ArrayList<ArrayList<Card>> ba) {
        this.ba = ba;
    }

    /**
     * プレイヤをプレイヤリストに追加する
     * @param player
     */
    public void addPlayer(Player player) {
        players.add(player);
    }

    /**
     * 場札にカードを出す
     * @param te
     */
    public void addBa(ArrayList<Card> te) {
        ba.add(te);
    }

    /**
     * 大富豪のルール（カードの数字の強さ）
     * @param te
     * @return カードが出せるならtrue，出せないならfalse
     */
    public boolean rule(ArrayList<Card> te) {
        switch (te.get(0).getNumber()) {
            case 0:
                return true;

            case 1:
                if (ba.size() == 0 || ba.get(ba.size() - 1).get(0).getNumber() > 2) {
                    return true;
                } else {
                    return false;
                }

            case 2:
                if (ba.size() == 0) {
                    return true;
                }
                if (ba.get(ba.size() - 1).get(0).getNumber() != 2 && ba.get(ba.size() - 1).get(0).getNumber() != 0) {
                    return true;
                } else {
                    return false;
                }

            default:
                if (ba.size() == 0 || te.get(0).getNumber() > ba.get(ba.size() - 1).get(0).getNumber()) {
                    if (ba.size() > 0 && ba.get(ba.size() - 1).get(0).getNumber() <= 2) {
                        return false;
                    } else
                        return true;
                } else {
                    return false;
                }

        }

    }

    /**
     * 大富豪の役を実装する
     * @param number カードの数字
     * @param i プレイヤの番号(0ならユーザ，0以外はCPU)
     */
    public void yaku(int number, int i) {
        switch (number) {
            case 7:
                System.out.println("!!! 7渡し !!!");
                int j;
                if (i == 0) {
                    System.out.println("カードを1枚次の人に渡すことができます．どれを渡しますか？(渡さない場合:-1)");
                    players.get(i).showTefuda();
                    j = KeyBoard.inputNumber();
                    while (j < -1 || j > players.get(i).getTefuda().size() - 1) {
                        System.out.println("[エラー]-1から" + (players.get(i).getTefuda().size() - 1) + "までの数字を入力してください．");
                        j = KeyBoard.inputNumber();
                    }
                } else {
                    j = rand.nextInt(players.get(i).getTefuda().size());
                }
                if (j == -1) {
                    break;
                } else {
                    Card c = players.get(i).getTefuda().get(j);
                    players.get(i).getTefuda().remove(c);
                    if (i == players.size() - 1) {
                        players.get(0).getTefuda().add(c);
                    } else {
                        players.get(i + 1).getTefuda().add(c);
                    }
                    System.out.println(c.toString() + "を渡しました．");
                }
                break;

            case 8:
                System.out.println("!!! 8切り !!!");
                System.out.println("場札を流します．");
                ba.clear();
                System.out.print("もう一度，");
                break;

            case 10:
                System.out.println("!!! 10捨て !!!");
                int k;
                if (i == 0) {
                    System.out.println("カードを1枚捨てることができます．どれを捨てますか？(捨てない場合:-1)");
                    players.get(i).showTefuda();
                    k = KeyBoard.inputNumber();
                    while (k < -1 || k > players.get(i).getTefuda().size() - 1) {
                        System.out.println("[エラー]-1から" + (players.get(i).getTefuda().size() - 1) + "までの数字を入力してください．");
                        k = KeyBoard.inputNumber();
                    }
                } else {
                    k = rand.nextInt(players.get(i).getTefuda().size());
                }
                if (k == -1) {
                    break;
                } else {
                    Card c = players.get(i).getTefuda().get(k);
                    players.get(i).getTefuda().remove(c);
                    System.out.println(c.toString() + "を捨てました．");
                }
                break;
        }

    }

    /**
     * 大富豪ゲームをスタートする
     */
    public void startGame() {
        Thread threadA = new Thread(new Runnable() {
            public void run() {
                System.out.println("■大富豪を開始します．");
                yamafuda.createFulDeck();
                yamafuda.shuffle();

                int n = players.size();
                int m = yamafuda.size() / n;

                try {
                    Thread.sleep(2*1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("■手札を配ります．");
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < m; j++) {
                        players.get(i).getTefuda().add(yamafuda.takeCard());
                    }
                }

                doDaifugo();
            }
        });
        threadA.start();


    }

    /**
     * 大富豪をする
     * @return 手札がなくなったらtrue
     */
    public void doDaifugo() {
        Thread threadB = new Thread(new Runnable(){
            public void run(){
                int count1 = 0;
                int count2 = 0;

                while (true) {
                    try {
                        Thread.sleep(2*1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    System.out.println("◎" + players.get(0).getName() + "の番です．");

                    if (count1 == players.size() - 1) {
                        System.out.println("他のプレイヤが全員パスしたので場のカードを流します．");
                        ba.clear();
                        count1 = 0;
                    }
                    int s;
                    if (ba.size() == 0) {
                        s = 0;
                    } else {
                        s = ba.get(ba.size() - 1).size();
                    }

                    System.out.println("[場札]");
                    if (ba.size() > 0) {
                        for (Card t : ba.get(ba.size() - 1)) {
                            t.show();
                        }
                    }
                    ArrayList<Card> te1 = players.get(0).chooseTe(s);

                    if (te1.size() > 0) {
                        while (rule(te1) == false) {
                            System.out.println("そのカードは出せません．別のカードを出す，もしくはパスしてください．");
                            te1 = players.get(0).chooseTe(s);
                            if (te1.size() == 0) {
                                break;
                            }
                        }

                        if (te1.size() == 0) {
                            System.out.println("パスしました．");
                            count1++;

                        } else {

                            addBa(te1);
                            for (Card v : te1) {
                                v.show();
                            }

                            for (Card u : te1) {
                                players.get(0).getTefuda().remove(u);
                            }
                            count1 = 0;
                            yaku(te1.get(0).getNumber(), 0);
                            if (te1.get(0).getNumber() == 8) {
                                continue;
                            }
                        }
                    }

                    else if (te1.size() == 0) {
                        System.out.println("パスしました．");
                        count1++;
                    }

                    if (players.get(0).getTefuda().size() == 0) {
                        System.out.println("◎手札がなくなりました．" + players.get(0).getName() + "の勝ちです!");
                        return ;
                    }

                    for (int i = 1; i < players.size(); i++) {
                        try {
                            Thread.sleep(2*1000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        System.out.println("◎CPU" + i + "の番です．[残り枚数：" + players.get(i).getTefuda().size() + "]");
                        if (count1 == players.size() - 1) {
                            System.out.println("他のプレイヤが全員パスしたので場のカードを流します．");
                            ba.clear();
                            count1 = 0;
                        }

                        if (ba.size() == 0) {
                            s = 0;
                        } else {
                            s = ba.get(ba.size() - 1).size();
                        }
                        ArrayList<Card> te2 = players.get(i).chooseTe(s);

                        if (te2.size() > 0) {
                            while (rule(te2) == false) {
                                te2 = players.get(i).chooseTe(s);
                                count2++;
                                if (count2 > 10) {
                                    te2.clear();
                                    break;
                                }

                                if (te2.size() == 0) {
                                    break;
                                }
                            }

                            if (te2.size() == 0) {
                                System.out.println("パスしました．");
                                count1++;

                            } else {

                                addBa(te2);
                                for (Card v : te2) {
                                    v.show();
                                }

                                for (Card u : te2) {
                                    players.get(i).getTefuda().remove(u);
                                }
                                count1 = 0;
                                yaku(te2.get(0).getNumber(), i);
                                if (te2.get(0).getNumber() == 8) {
                                    i--;
                                    continue;
                                }
                            }
                        }

                        else if (te2.size() == 0) {
                            System.out.println("パスしました．");
                            count1++;
                        }

                        if (players.get(i).getTefuda().size() == 0) {
                            System.out.println(
                                    "◎" + players.get(i).getName() + "の手札がなくなりました．" + players.get(i).getName() + "の勝ちです!");
                            return ;
                        }

                    }
                }


            }
        });

        threadB.start();

    }

}
