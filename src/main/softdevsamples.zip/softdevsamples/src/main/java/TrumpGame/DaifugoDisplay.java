package TrumpGame;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

import TrumpGame.Card;
import TrumpGame.CardDeck;
import TrumpGame.Player;

import javax.swing.*;

/**
 * 大富豪ゲームを表すクラス
 *
 * @author 浅野卓磨
 */
public class DaifugoDisplay {
    /**
     * プレイヤリスト
     */
    private ArrayList<Player> players = new ArrayList<Player>();
    /**
     * 場札
     */
    private ArrayList<ArrayList<Card>> ba = new ArrayList<ArrayList<Card>>();
    /**
     * 山札
     */
    private CardDeck yamafuda = new CardDeck();

    private JFrame disp;

    private
    JPanel top_panel, mid_panel1, mid_panel2, bottom_panel;

    private JLabel msg_lbl;

    private JButton btn_0, btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_10, btn_11, btn_12;
    private ArrayList<JButton> btns = new ArrayList<JButton>();

    private JButton pass, take;

    private JLabel first_lbl, first_suit_lbl, first_no_lbl, second_lbl, second_suit_lbl, second_no_lbl,
            third_lbl, thied_suit_lbl, third_no_lbl, fourth_lbl, fourth_suit_lbl, fourth_no_lbl;


    Random rand = new Random();

    /**
     * 空の大富豪ゲームインスタンスを作る
     */
    public DaifugoDisplay() {
        super();

        disp = new JFrame("Daifugo");
        disp.setSize(1300, 700);
        disp.setLocationRelativeTo(null);
        disp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        disp.setResizable(false);

        top_panel = new JPanel();
        setPanel(top_panel, Color.ORANGE, null, new Dimension(1300, 200));
        disp.add(top_panel, BorderLayout.NORTH);

        msg_lbl = new JLabel();
        top_panel.add(msg_lbl);
        setLabelFont(msg_lbl, Color.BLACK, 0, 15, 1300, 20, 20, false);

        mid_panel1 = new JPanel();
        setPanel(mid_panel1, Color.CYAN, null, new Dimension(1100, 400));
        disp.add(mid_panel1, BorderLayout.CENTER);

        mid_panel2 = new JPanel();
        setPanel(mid_panel2, Color.LIGHT_GRAY, new BoxLayout(mid_panel2, BoxLayout.Y_AXIS), new Dimension(200, 400));
        disp.add(mid_panel2, BorderLayout.EAST);

        first_lbl = new JLabel("私のカード");
        first_suit_lbl = new JLabel();
        first_no_lbl = new JLabel("?");

        mid_panel1.add(first_lbl);
        mid_panel1.add(first_suit_lbl);
        mid_panel1.add(first_no_lbl);

        setLabelFont(first_lbl, Color.CYAN, 90, 20, 100, 20, 14, false);
        setLabelFont(first_suit_lbl, Color.CYAN, 100, 20, 120, 150, 16, false);
        setLabelFont(first_no_lbl, Color.CYAN, 100, 45, 120, 150, 16, true);

        second_lbl = new JLabel("あなたのカード");
        second_suit_lbl = new JLabel("!");
        second_no_lbl = new JLabel("？");

        mid_panel1.add(second_lbl);
        mid_panel1.add(second_suit_lbl);
        mid_panel1.add(second_no_lbl);

        setLabelFont(second_lbl, Color.CYAN, 265, 20, 150, 20, 14, false);
        setLabelFont(second_suit_lbl, Color.CYAN, 300, 20, 120, 150, 16, false);
        setLabelFont(second_no_lbl, Color.CYAN, 300, 45, 120, 150, 16, true);

        third_lbl = new JLabel("あなたのカード");
        thied_suit_lbl = new JLabel("!");
        third_no_lbl = new JLabel("？");

        mid_panel1.add(third_lbl);
        mid_panel1.add(thied_suit_lbl);
        mid_panel1.add(third_no_lbl);

        setLabelFont(third_lbl, Color.CYAN, 440, 20, 150, 20, 14, false);
        setLabelFont(thied_suit_lbl, Color.CYAN, 500, 20, 120, 150, 16, false);
        setLabelFont(third_no_lbl, Color.CYAN, 500, 45, 120, 150, 16, true);

        fourth_lbl = new JLabel("あなたのカード");
        fourth_suit_lbl = new JLabel("!");
        fourth_no_lbl = new JLabel("？");

        mid_panel1.add(fourth_lbl);
        mid_panel1.add(fourth_suit_lbl);
        mid_panel1.add(fourth_no_lbl);

        setLabelFont(fourth_lbl, Color.CYAN, 265, 20, 150, 20, 14, false);
        setLabelFont(fourth_suit_lbl, Color.CYAN, 700, 20, 120, 150, 16, false);
        setLabelFont(fourth_no_lbl, Color.CYAN, 700, 45, 120, 150, 16, true);


        bottom_panel = new JPanel();
        setPanel(bottom_panel, Color.GREEN, new BoxLayout(bottom_panel, BoxLayout.X_AXIS), new Dimension(1300, 100));
        disp.add(bottom_panel, BorderLayout.SOUTH);


        btn_0 = new JButton();
        //btn_0.setIcon(new ImageIcon("src/main/resources/img/cards/card_club_01.png"));
        btns.add(btn_0);
        btn_1 = new JButton();
        btns.add(btn_1);
        btn_2 = new JButton();
        btns.add(btn_2);
        btn_3 = new JButton();
        btns.add(btn_3);
        btn_4 = new JButton();
        btns.add(btn_4);
        btn_5 = new JButton();
        btns.add(btn_5);
        btn_6 = new JButton();
        btns.add(btn_6);
        btn_7 = new JButton();
        btns.add(btn_7);
        btn_8 = new JButton();
        btns.add(btn_8);
        btn_9 = new JButton();
        btns.add(btn_9);
        btn_10 = new JButton();
        btns.add(btn_10);
        btn_11 = new JButton();
        btns.add(btn_11);
        btn_12 = new JButton();
        btns.add(btn_12);

        for (int i = 0; i < 13; i++) {
            setButton(btns.get(i), 10, 50, 20);
            int finalI = i;
            btns.get(i).addActionListener((e) -> select(finalI));
            bottom_panel.add(btns.get(i));
        }

        take = new JButton("出す");
        pass = new JButton("パス");

        mid_panel2.add(take);
        mid_panel2.add(pass);


        disp.setVisible(true);

    }

    /**
     * プレイヤリストを取得する
     *
     * @return プレイヤリスト
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * プレイヤリストをセットする
     *
     * @param players
     */
    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    /**
     * 場札を取得する
     *
     * @return 場札
     */
    public ArrayList<ArrayList<Card>> getBa() {
        return ba;
    }

    /**
     * 場札をセットする
     *
     * @param ba
     */
    public void setBa(ArrayList<ArrayList<Card>> ba) {
        this.ba = ba;
    }

    /**
     * プレイヤをプレイヤリストに追加する
     *
     * @param player
     */
    public void addPlayer(Player player) {
        players.add(player);
    }

    /**
     * 場札にカードを出す
     *
     * @param te
     */
    public void addBa(ArrayList<Card> te) {
        ba.add(te);
    }

    /**
     * 大富豪のルール（カードの数字の強さ）
     *
     * @param te
     * @return カードが出せるならtrue，出せないならfalse
     */
    public boolean rule(ArrayList<Card> te) {
        switch (te.get(0).getNumber()) {
            case 0:
                return true;

            case 1:
                if (ba.size() == 0 || ba.get(ba.size() - 1).get(0).getNumber() > 2) {
                    return true;
                } else {
                    return false;
                }

            case 2:
                if (ba.size() == 0) {
                    return true;
                }
                if (ba.get(ba.size() - 1).get(0).getNumber() != 2 && ba.get(ba.size() - 1).get(0).getNumber() != 0) {
                    return true;
                } else {
                    return false;
                }

            default:
                if (ba.size() == 0 || te.get(0).getNumber() > ba.get(ba.size() - 1).get(0).getNumber()) {
                    if (ba.size() > 0 && ba.get(ba.size() - 1).get(0).getNumber() <= 2) {
                        return false;
                    } else
                        return true;
                } else {
                    return false;
                }

        }

    }

    /**
     * 大富豪の役を実装する
     *
     * @param number カードの数字
     * @param i      プレイヤの番号(0ならユーザ，0以外はCPU)
     */
    public void yaku(int number, int i) {
        switch (number) {
            case 7:
                System.out.println("!!! 7渡し !!!");
                int j;
                if (i == 0) {
                    System.out.println("カードを1枚次の人に渡すことができます．どれを渡しますか？(渡さない場合:-1)");
                    players.get(i).showTefuda();
                    j = KeyBoard.inputNumber();
                    while (j < -1 || j > players.get(i).getTefuda().size() - 1) {
                        System.out.println("[エラー]-1から" + (players.get(i).getTefuda().size() - 1) + "までの数字を入力してください．");
                        j = KeyBoard.inputNumber();
                    }
                } else {
                    j = rand.nextInt(players.get(i).getTefuda().size());
                }
                if (j == -1) {
                    break;
                } else {
                    Card c = players.get(i).getTefuda().get(j);
                    players.get(i).getTefuda().remove(c);
                    if (i == players.size() - 1) {
                        players.get(0).getTefuda().add(c);
                    } else {
                        players.get(i + 1).getTefuda().add(c);
                    }
                    System.out.println(c.toString() + "を渡しました．");
                }
                break;

            case 8:
                System.out.println("!!! 8切り !!!");
                System.out.println("場札を流します．");
                ba.clear();
                System.out.print("もう一度，");
                break;

            case 10:
                System.out.println("!!! 10捨て !!!");
                int k;
                if (i == 0) {
                    System.out.println("カードを1枚捨てることができます．どれを捨てますか？(捨てない場合:-1)");
                    players.get(i).showTefuda();
                    k = KeyBoard.inputNumber();
                    while (k < -1 || k > players.get(i).getTefuda().size() - 1) {
                        System.out.println("[エラー]-1から" + (players.get(i).getTefuda().size() - 1) + "までの数字を入力してください．");
                        k = KeyBoard.inputNumber();
                    }
                } else {
                    k = rand.nextInt(players.get(i).getTefuda().size());
                }
                if (k == -1) {
                    break;
                } else {
                    Card c = players.get(i).getTefuda().get(k);
                    players.get(i).getTefuda().remove(c);
                    System.out.println(c.toString() + "を捨てました．");
                }
                break;
        }

    }

    /**
     * 大富豪ゲームをスタートする
     */
    public void startGame() {
        msg_lbl.setText("■大富豪を開始します．");
        //System.out.println("■大富豪を開始します．");
        yamafuda.createFulDeck();
        yamafuda.shuffle();

        int n = players.size();
        int m = yamafuda.size() / n;

        try {
            Thread.sleep(3 * 1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        msg_lbl.setText("■手札を配ります．");
        //System.out.println("■手札を配ります．");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                players.get(i).getTefuda().add(yamafuda.takeCard());
            }
        }

        doDaifugo();


    }

    public void select(int n) {
        msg_lbl.setText("selected " + n);
    }

    // パネルのフォント設定を行うメソッド
    public static void setPanel(JPanel panel, Color color, BoxLayout layout, Dimension dimension) {
        panel.setBackground(color);        // 背景色を設定
        panel.setLayout(layout);           // レイアウトを設定
        panel.setPreferredSize(dimension); // 表示サイズを設定

        return;
    }

    // ラベルのフォント設定を行うメソッド
    public static void setLabelFont(JLabel label, Color clr,
                                    int x_pos, int y_pos,
                                    int x_size, int y_size,
                                    int strSize, boolean opq) {
        label.setBackground(clr);        // 背景色を設定
        label.setLocation(x_pos, y_pos); // 表示位置を設定
        label.setSize(x_size, y_size);   // 表示サイズを設定
        label.setFont(new Font("ＭＳ ゴシック", Font.PLAIN, strSize)); // 書式、文字サイズを設定
        label.setHorizontalAlignment(JLabel.CENTER); // 水平方向中央揃え
        label.setVerticalAlignment(JLabel.CENTER);   // 垂直方向中央揃え
        label.setOpaque(opq); // ラベルの透明性を設定(true＝不透明、false＝透明)

        return;
    }

    // ボタンの設定を行うメソッド
    public static void setButton(JButton btn, int x_size, int y_size, int strSize) {
        btn.setPreferredSize(new Dimension(x_size, y_size));      // 表示サイズを設定
        btn.setFont(new Font("ＭＳ ゴシック", Font.PLAIN, strSize)); // 書式、文字サイズを設定


        return;
    }

    /**
     * 大富豪をする
     *
     * @return 手札がなくなったらtrue
     */
    public void doDaifugo() {
        int count1 = 0;
        int count2 = 0;

        try {
            Thread.sleep(2 * 1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        msg_lbl.setText("start");

        while (true) {
            try {
                Thread.sleep(2 * 1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("◎" + players.get(0).getName() + "の番です．");
            msg_lbl.setText("◎" + players.get(0).getName() + "の番です．");


            if (count1 == players.size() - 1) {
                System.out.println("他のプレイヤが全員パスしたので場のカードを流します．");
                msg_lbl.setText("他のプレイヤが全員パスしたので場のカードを流します．");
                ba.clear();
                count1 = 0;
            }
            int s;
            if (ba.size() == 0) {
                s = 0;
            } else {
                s = ba.get(ba.size() - 1).size();
            }

            System.out.println("[場札]");
            if (ba.size() > 0) {
                int i = 0;
                for (Card t : ba.get(ba.size() - 1)) {
                    t.show();
                    initBa(i, t);
                    arrangeBa(i, t);
                    i++;
                }
            }
            players.get(0).sort();
            for (int i = 0; i < players.get(0).tefuda.size(); i++) {
                btns.get(i).setText(players.get(0).tefuda.get(i).toString());
            }
            ArrayList<Card> te1 = players.get(0).chooseTe(s);

            if (te1.size() > 0) {
                while (rule(te1) == false) {
                    System.out.println("そのカードは出せません．別のカードを出す，もしくはパスしてください．");
                    msg_lbl.setText("そのカードは出せません．別のカードを出す，もしくはパスしてください．");

                    te1 = players.get(0).chooseTe(s);
                    if (te1.size() == 0) {
                        break;
                    }
                }

                if (te1.size() == 0) {
                    System.out.println("パスしました．");
                    msg_lbl.setText("パスしました．");
                    count1++;

                } else {

                    addBa(te1);
                    for (Card v : te1) {
                        v.show();
                    }

                    for (Card u : te1) {
                        players.get(0).getTefuda().remove(u);
                    }
                    count1 = 0;
                    yaku(te1.get(0).getNumber(), 0);
                    if (te1.get(0).getNumber() == 8) {
                        continue;
                    }
                }
            } else if (te1.size() == 0) {
                System.out.println("パスしました．");
                msg_lbl.setText("パスしました．");
                count1++;
            }

            if (players.get(0).getTefuda().size() == 0) {
                System.out.println("◎手札がなくなりました．" + players.get(0).getName() + "の勝ちです!");
                msg_lbl.setText("◎手札がなくなりました．" + players.get(0).getName() + "の勝ちです!");
                return;
            }

            for (int i = 1; i < players.size(); i++) {
                try {
                    Thread.sleep(2 * 1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("◎CPU" + i + "の番です．[残り枚数：" + players.get(i).getTefuda().size() + "]");
                msg_lbl.setText("◎CPU" + i + "の番です．[残り枚数：" + players.get(i).getTefuda().size() + "]");
                if (count1 == players.size() - 1) {
                    System.out.println("他のプレイヤが全員パスしたので場のカードを流します．");
                    msg_lbl.setText("他のプレイヤが全員パスしたので場のカードを流します．");
                    ba.clear();
                    count1 = 0;
                }

                if (ba.size() == 0) {
                    s = 0;
                } else {
                    s = ba.get(ba.size() - 1).size();
                }

                System.out.println("[場札]");
                if (ba.size() > 0) {
                    for (Card t : ba.get(ba.size() - 1)) {
                        t.show();
                    }
                }

                ArrayList<Card> te2 = players.get(i).chooseTe(s);

                if (te2.size() > 0) {
                    while (rule(te2) == false) {
                        te2 = players.get(i).chooseTe(s);
                        count2++;
                        if (count2 > 10) {
                            te2.clear();
                            break;
                        }

                        if (te2.size() == 0) {
                            break;
                        }
                    }

                    if (te2.size() == 0) {
                        System.out.println("パスしました．");
                        msg_lbl.setText("パスしました．");
                        count1++;

                    } else {

                        addBa(te2);
                        for (Card v : te2) {
                            v.show();
                        }

                        for (Card u : te2) {
                            players.get(i).getTefuda().remove(u);
                        }
                        count1 = 0;
                        yaku(te2.get(0).getNumber(), i);
                        if (te2.get(0).getNumber() == 8) {
                            i--;
                            continue;
                        }
                    }
                } else if (te2.size() == 0) {
                    System.out.println("パスしました．");
                    msg_lbl.setText("パスしました．");
                    count1++;
                }

                if (players.get(i).getTefuda().size() == 0) {
                    System.out.println(
                            "◎" + players.get(i).getName() + "の手札がなくなりました．" + players.get(i).getName() + "の勝ちです!");
                    msg_lbl.setText(
                            "◎" + players.get(i).getName() + "の手札がなくなりました．" + players.get(i).getName() + "の勝ちです!");
                    return;
                }

            }
        }

    }

    public void arrangeBa(int i, Card t) {
        if (i == 0) {
            first_no_lbl.setBackground((Color.WHITE));
            first_no_lbl.setText(t.getStringNumber(t.getNumber()));
            first_suit_lbl.setBackground(Color.WHITE);
            first_suit_lbl.setText(t.getStringSuit(t.getSuit()));
        } else if (i == 1) {
            second_no_lbl.setBackground((Color.WHITE));
            second_no_lbl.setText(t.getStringNumber(t.getNumber()));
            second_suit_lbl.setBackground(Color.WHITE);
            second_suit_lbl.setText(t.getStringSuit(t.getSuit()));
        } else if (i == 2) {
            third_no_lbl.setBackground((Color.WHITE));
            third_no_lbl.setText(t.getStringNumber(t.getNumber()));
            thied_suit_lbl.setBackground(Color.WHITE);
            thied_suit_lbl.setText(t.getStringSuit(t.getSuit()));
        } else if (i == 3) {
            fourth_no_lbl.setBackground((Color.WHITE));
            fourth_no_lbl.setText(t.getStringNumber(t.getNumber()));
            fourth_suit_lbl.setBackground(Color.WHITE);
            fourth_suit_lbl.setText(t.getStringSuit(t.getSuit()));
        }
    }

    public void initBa(int i, Card t) {

        first_no_lbl.setBackground((Color.CYAN));
        first_no_lbl.setText("");
        first_suit_lbl.setBackground(Color.CYAN);
        first_suit_lbl.setText("");

        second_no_lbl.setBackground((Color.CYAN));
        second_no_lbl.setText("");
        second_suit_lbl.setBackground(Color.CYAN);
        second_suit_lbl.setText("");

        third_no_lbl.setBackground((Color.CYAN));
        third_no_lbl.setText("");
        thied_suit_lbl.setBackground(Color.CYAN);
        thied_suit_lbl.setText("");

        fourth_no_lbl.setBackground((Color.CYAN));
        fourth_no_lbl.setText("");
        fourth_suit_lbl.setBackground(Color.CYAN);
        fourth_suit_lbl.setText("");
    }

}
