package TrumpGame;

import TrumpGame.DaifugoApplication;
import kobeU.cs.samplesGUI.SampleDrawPanel;
import kobeU.cs.samplesGUI.SampleMix;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Main {


    public static void main(String[] args) {
        DaifugoApplication da = new DaifugoApplication();
        da.startApplication();
    }

}

