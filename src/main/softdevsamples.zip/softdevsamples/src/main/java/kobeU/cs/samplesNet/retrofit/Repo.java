package kobeU.cs.samplesNet.retrofit;

public class Repo {
    public String id;
    public String node_id;
    public String name;
    public String toString() {
        return ""+id+":"+node_id+":"+name;
    }
}
