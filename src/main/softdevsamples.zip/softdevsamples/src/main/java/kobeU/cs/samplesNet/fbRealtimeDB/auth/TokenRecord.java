package kobeU.cs.samplesNet.fbRealtimeDB.auth;

public class TokenRecord {
    public String idToken;
}
