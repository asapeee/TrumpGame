package kobeU.cs.samplesNet.fbRealtimeDB.auth;

public class AuthRequest {
    public boolean returnSecureToken;
    public String email;
    public String password;
}
