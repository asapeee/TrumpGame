
image file の表示テスト用サンプルデータ

* 出展：[いらすとや](https://www.irasutoya.com/)